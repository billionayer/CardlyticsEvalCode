﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TriangleTypeChecker.BusinessServices
{
    public class Triangles : List<Triangles>
    {
    }
}
